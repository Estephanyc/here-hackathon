export interface GeoFireObj {
  '.priority': string;
  g: string;
  l: number[];
}